from pubnub.callbacks import SubscribeCallback
from pubnub.enums import PNStatusCategory
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
import json


def publish_callback(result, status):
    print result
    if status.is_error():
        print "error message"

def lambda_handler(event, context):
    pnconfig = PNConfiguration()
    pnconfig.subscribe_key = 'sub-c-a1a1d502-b5b9-11e7-af03-56d0cae65fed'
    pnconfig.publish_key = 'pub-c-eaf36626-1b19-4b11-aecb-d75bea103006'
    pnconfig.ssl = False
    pubnub = PubNub(pnconfig)
    #print(event)
    if(event['FLEET'] == 'FL1502'):
        input_message =  { 'eon': { event['FLEET']: event['VELOCITY']}}
        print(input_message)
        pubnub.publish().channel('iot-kalyan-velocity-aws').message(input_message).async(publish_callback)    
        return input_message
    else:
        return "Non-Message"
