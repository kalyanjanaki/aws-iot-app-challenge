from pubnub.callbacks import SubscribeCallback
from pubnub.enums import PNStatusCategory
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub
import json
from random import randint
import time
import base64
import boto3

dynamodb = boto3.resource('dynamodb')
fleet_table = dynamodb.Table('Fleet-Details')

pnconfig = PNConfiguration()
pnconfig.subscribe_key = 'pub-c-eaf36626-1b19-4b11-aecb-d75bea103006'
pnconfig.publish_key = 'sub-c-a1a1d502-b5b9-11e7-af03-56d0cae65fed'
pnconfig.ssl = False
pubnub = PubNub(pnconfig)

def publish_callback(result, status):
    print result
    if status.is_error():
        print "error message"

def lambda_handler(event, context):
    # Convert the Payload from 
    payload = base64.b64decode(event['Records'][0]['kinesis']['data'])
    payload = json.loads(payload)
    # Read Current Status of the Fleet From Table.
    fleet_val = fleet_table.get_item(
        Key={
            'serial-number': payload['fleet']
        })
    # calculate the New mileages and Thread Lenghts and Update table 
    add_mileage =  float(payload['mileage']) - float(fleet_val['Item']['initialMileage'] )
    new_mileage = str(float(fleet_val['Item']['initialMileage']) + add_mileage)
    mileage_vals = fleet_val['Item']['mileage']
    thread_vals = fleet_val['Item']['threadLength']
    new_ml = {}
    new_ml['FL'] = str(float(mileage_vals['FL']) + add_mileage)
    new_ml['FR'] = str(float(mileage_vals['FR']) + add_mileage)
    new_ml['ML1'] = str(float(mileage_vals['ML1']) + add_mileage)
    new_ml['ML2'] = str(float(mileage_vals['ML2']) + add_mileage)
    new_ml['MR1'] = str(float(mileage_vals['MR1']) + add_mileage)
    new_ml['MR2'] = str(float(mileage_vals['MR2']) + add_mileage)
    new_ml['RL'] = str(float(mileage_vals['RL']) + add_mileage)
    new_ml['RR'] = str(float(mileage_vals['RR']) + add_mileage)
    new_thread = {}
    new_thread['FL'] = str(float(thread_vals['FL']) - 1.0)
    new_thread['FR'] = str(float(thread_vals['FR']) - 1.0)
    new_thread['ML1'] = str(float(thread_vals['ML1']) - 1.0)
    new_thread['ML2'] = str(float(thread_vals['ML2']) - 1.0)
    new_thread['MR1'] = str(float(thread_vals['MR1']) - 1.0)
    new_thread['MR2'] = str(float(thread_vals['MR2']) - 1.0)
    new_thread['RL'] = str(float(thread_vals['RL']) - 1.0)
    new_thread['RR'] = str(float(thread_vals['RR']) - 1.0)
    expressionval = { ':val1' : new_mileage, ':val2' : new_ml, ':val3' : new_thread }
    keyval = {'serial-number' : payload['fleet']}
    fleet_table.update_item(
        Key=keyval,
        ExpressionAttributeValues=expressionval,
        UpdateExpression='SET initialMileage = :val1, mileage = :val2, threadLength = :val3')
    msg_val = float(thread_vals['FL']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-FL').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['FR']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-FR').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['ML1']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-ML1').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['ML2']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-ML2').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['MR1']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-MR1').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['MR2']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-MR2').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['RL']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-RL').message(input_message).async(publish_callback)
    msg_val = float(thread_vals['RR']) - 1.0
    input_message =  { 'eon': { 'data': msg_val }}    
    pubnub.publish().channel('kalyan-iot-RR').message(input_message).async(publish_callback)

    return "Done with function" 

